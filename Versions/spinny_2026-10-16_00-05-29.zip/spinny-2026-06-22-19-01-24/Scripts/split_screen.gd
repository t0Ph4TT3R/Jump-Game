extends Control

@onready var players: Array[Dictionary] = [
	{
		subviewport = $HSplitContainer/SubViewportContainer1/leftSubViewport,
		camera = $HSplitContainer/SubViewportContainer1/leftCam,
		player = $HSplitContainer/SubViewportContainer1/leftSubViewport/Terrain/player,
	}, {
		subviewport = $HSplitContainer/SubViewportContainer2/rightSubViewport,
		camera = $HSplitContainer/SubViewportContainer2/rightCam,
		player = $HSplitContainer/SubViewportContainer1/leftSubViewport/Terrain/player2,
	},
]

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	players[1].subviewport.world_2d = players[0].subviewport.world_2d
	
	for info in players:
		var remote_transform = RemoteTransform2D.new()
		remote_transform.remote_path = info.camera.get_path()
		info.player.add_child(remote_transform)
