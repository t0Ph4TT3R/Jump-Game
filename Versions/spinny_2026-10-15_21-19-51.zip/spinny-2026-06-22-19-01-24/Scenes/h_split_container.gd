extends HSplitContainer

@onready var players: Array[Dictionary] = [
	{
		subviewport = $HSplitContainer/SubViewportContainer1/leftSubViewport,
		camera = $HSplitContainer/SubViewportContainer1/leftSubViewport/leftCam,
		player = $HSplitContainer/SubViewportContainer1/leftSubViewport/Terrain/player,
	}, {
		subviewport = $HSplitContainer/SubViewportContainer2/rightSubViewport,
		camera = $HSplitContainer/SubViewportContainer2/rightCam,
		player = $HSplitContainer/SubViewportContainer1/leftSubViewport/Terrain/player2
	}
]

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
